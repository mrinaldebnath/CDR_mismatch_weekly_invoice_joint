package com.weeklyInvoice;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class ReadXLS {
	
	public static void readXLSFile() throws IOException
	{
		InputStream ExcelFileToRead = new FileInputStream("C:\\Users\\Omnia\\Google Drive\\Invoice\\Invoice Carrier-1 (1)\\Invoice Carrier-1 2018\\Carrier-1 19 February-25 February 2018\\CDR _ SOA Carrier-1 19-25 february '18.xls");
		HSSFWorkbook wb = new HSSFWorkbook(ExcelFileToRead);
		
		//HSSFWorkbook wb_new = new HSSFWorkbook("C:\\\\\\\\Users\\\\\\\\Omnia\\\\\\\\Google Drive\\\\\\\\Invoice\\\\\\\\Invoice Carrier-1 (1)\\\\\\\\Invoice Carrier-1 2018\\\\\\\\Carrier-1 19 February-25 February 2018\\\\\\\\CDR _ SOA Carrier-1 19-25 february '18.xls");
	
	}
	
public static void main(String[] args) throws IOException {
		

		readXLSFile();
		

	}
	
}
