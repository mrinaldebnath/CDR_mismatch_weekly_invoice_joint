package com.weeklyInvoice;

import java.util.HashMap;
import java.util.Map;

public class carrierNameDateMap {
	Map<String,String[]> carrierNameDateMap;

	public carrierNameDateMap() {
		super();
		this.carrierNameDateMap=new HashMap<String, String[]>();
	}
	
	
}
