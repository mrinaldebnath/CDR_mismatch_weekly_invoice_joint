package com.weeklyInvoice;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.omg.IOP.ExceptionDetailMessage;

public class FolderCreation {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		int MILLIS_IN_DAY = 1000 * 60 * 60 * 24;

		// String[] listOfCarrierName = { "Ivoco", "Carrier-1",  "INS","SaifTelecom","Mainberg","SajiaAssociates",
		//  "Big Leap","MagikTel", "Inaani",
		// "PMB" };

//		String[] listOfCarrierName = {"Ivoco", "Carrier-1",  "INS","SaifTelecom","Mainberg"};

		String[] listOfCarrierName = {"INS","SaifTelecom","Mainberg"};
		
		int sizeOfListOfCarrierName = listOfCarrierName.length;

		for (int carrierIndex = 0; carrierIndex < sizeOfListOfCarrierName; carrierIndex++) {

			String carrierName = listOfCarrierName[carrierIndex];
			System.out.println(carrierName);

			File yearDir = new File("C:\\Users\\Omnia\\Google Drive\\Invoice\\Invoice " + carrierName + " (1)\\Invoice "
					+ carrierName + " 2018");

			File[] listOfYearlyFiles = yearDir.listFiles();
			int numberInsideYear = listOfYearlyFiles.length;
			Date tempForLastDate = new Date(117, 11, 31);
			int tempforLastIndex = 0;

			for (int yearIndex = 0; yearIndex < numberInsideYear; yearIndex++) {

				File fileToCheck = listOfYearlyFiles[yearIndex];
				String fileName = fileToCheck.getName();

				if (fileName.equals("desktop.ini") || fileName.equals("TrackDate.txt") || fileName.equals("LastInvoiceTrackDate.txt"))
					continue;

				String lastDateString = fileName.substring(fileName.lastIndexOf("-") + 1);
				Date lastDate = new Date();
				try {
					lastDate = new SimpleDateFormat("dd MMMM yyyy").parse(lastDateString);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (lastDate.after(tempForLastDate)) {
					tempForLastDate = lastDate;
					tempforLastIndex = yearIndex;
				}

			}

			File srcDir = new File(listOfYearlyFiles[tempforLastIndex].getAbsolutePath());

			String onlyLastInvoiceDateName = srcDir.getName();
			String firstPart = onlyLastInvoiceDateName.substring(0, onlyLastInvoiceDateName.lastIndexOf('-'));
			String endDateLastInvoice = onlyLastInvoiceDateName.substring(onlyLastInvoiceDateName.lastIndexOf('-') + 1);
			int startDatecountIndex = firstPart.substring(0,firstPart.substring(0, firstPart.lastIndexOf(' ')).lastIndexOf(' ')).lastIndexOf(' ') + 1;
			String startDateLastInvoice = firstPart.substring(startDatecountIndex);

			SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMMM yyyy");

			Date today = new Date();
			Date sunday = today;
			sunday.setTime(today.getTime() - MILLIS_IN_DAY);
			int diffFromSunday = sunday.getDay();

			sunday.setTime(sunday.getTime() - (diffFromSunday * MILLIS_IN_DAY));

			String newFirstDateString = dateFormat.format(tempForLastDate.getTime() + MILLIS_IN_DAY);
			String newLastDateString = dateFormat.format(sunday.getTime());

			String stringToWriteDate = newFirstDateString + "-" + newLastDateString;
			byte data[] = stringToWriteDate.getBytes();
			FileOutputStream out = new FileOutputStream("C:\\Users\\Omnia\\Google Drive\\Invoice\\Invoice "
					+ carrierName + " (1)\\Invoice " + carrierName + " 2018\\" + "TrackDate.txt");
			out.write(data);
			out.close();

			String lastInvoiceDate = startDateLastInvoice + "-" + endDateLastInvoice;
			data = lastInvoiceDate.getBytes();
			out = new FileOutputStream("C:\\Users\\Omnia\\Google Drive\\Invoice\\Invoice "
					+ carrierName + " (1)\\Invoice " + carrierName + " 2018\\" + "LastInvoiceTrackDate.txt");
			out.write(data);
			out.close();

			File destDir = new File("C:\\Users\\Omnia\\Google Drive\\Invoice\\Invoice " + carrierName + " (1)\\Invoice "
					+ carrierName + " 2018\\" + carrierName + " " + newFirstDateString + "-" + newLastDateString);

			File[] listOfWeeklyFiles = srcDir.listFiles();

			File cdr_SOA = listOfWeeklyFiles[0];
			File invoice_Doc = listOfWeeklyFiles[3];

			String name_CDR_SOA = cdr_SOA.getName();
			String name_Invoice_Doc = invoice_Doc.getName();

			if (name_CDR_SOA.startsWith("CDR")) {
				try {
					FileUtils.copyFileToDirectory(cdr_SOA, destDir);
					File destCDR = new File(destDir + "\\CDR_SOA " + carrierName + " " + newFirstDateString + "-"
							+ newLastDateString + " temp.xls");
					File CDRNameToBeChanged = new File(destDir + "\\" + name_CDR_SOA);
					CDRNameToBeChanged.renameTo(destCDR);

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				try {
					throw new Exception("CDR_SOA file is not at 0th index for " + carrierName + " " + newFirstDateString
							+ "-" + newLastDateString);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			if (carrierName.equals("Mainberg")) {
				if (name_Invoice_Doc.substring(name_Invoice_Doc.indexOf('.')).equals(".doc")) {
					try {
						FileUtils.copyFileToDirectory(invoice_Doc, destDir);
						File destInvoice = new File(destDir + "\\Invoice " + carrierName + " " + newFirstDateString
								+ "-" + newLastDateString + ".doc");
						File invoiceNameToBeChanged = new File(destDir + "\\" + name_Invoice_Doc);
						invoiceNameToBeChanged.renameTo(destInvoice);

					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} else {
					try {
						throw new Exception("Invoice doc file is not at 3rd index for " + carrierName + " "
								+ newFirstDateString + "-" + newLastDateString);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} 
			}

		}

	}

}
